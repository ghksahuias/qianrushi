/********************************** (C) COPYRIGHT  *******************************
* File Name          : debug.h
* Author             : WCH
* Version            : V1.0.0
* Date               : 2021/06/06
* Description        : This file contains all the functions prototypes for UART
*                      Printf , Delay functions.
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* SPDX-License-Identifier: Apache-2.0
*******************************************************************************/
#ifndef __DEBUG_H
#define __DEBUG_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "stdio.h"
#include "ch32v30x.h"

/* UART Printf Definition */
#define DEBUG_UART1    1
#define DEBUG_UART2    2
#define DEBUG_UART3    3

/* DEBUG UATR Definition */
//#define DEBUG   DEBUG_UART1
//#define DEBUG   DEBUG_UART2
#define DEBUG   DEBUG_UART1

//L.Q UART RX �ܽ�ö��
typedef enum
{//UART�л� ���ܸ���BIT15-12 ����BIT11-8 PORT����BIT7-4  �ܽ�˳��BIT3-0
   UART1_RX_A10 = 0x100A,  // AF Ĭ������
   UART1_RX_B7  = 0x2017,  // AF2 PORTB B7
   UART2_RX_A3  = 0x1003,  // AF1
   UART2_RX_D6  = 0x2036,  // AF2
   UART3_RX_B11 = 0x101B,  // AF1
   UART3_RX_C11 = 0x202B,  // AF2
   UART3_RX_D9  = 0x2039,  // AF2
   UART4_RX_B1  = 0x2011,  // AF2
   UART4_RX_E1  = 0x2041,  // AF2
   UART4_RX_C11 = 0x102B,  // AF1
   UART5_RX_E9  = 0x2049,  // AF2
   UART5_RX_B5  = 0x2015,  // AF2
   UART5_RX_D2  = 0x1032,  // AF1
   UART6_RX_C1  = 0x1031,  // AF1
   UART6_RX_E11 = 0x204B,  // AF2
   UART6_RX_B9  = 0x2019,  // AF2
   UART7_RX_E13 = 0x204D,  // AF2
   UART7_RX_A7  = 0x2007,  // AF2
   UART7_RX_C3  = 0x1023,  // AF1
   UART8_RX_E15 = 0x204F,  // AF2
   UART8_RX_A15 = 0x200F,  // AF2
   UART8_RX_C5  = 0x1025,  // AF1
}UART_RX_e;

//L.Q UART TX �ܽ�ö��
typedef enum
{
   UART1_TX_A9  = 0x1009,  //Ĭ������
   UART1_TX_B15 = 0x201F,  // AF2
   UART1_TX_B6  = 0x2016,  // AF2
   UART2_TX_A2  = 0x1002,  // AF1
   UART2_TX_D5  = 0x2035,  // AF2
   UART3_TX_B10 = 0x101A,  // AF1
   UART3_TX_C10 = 0x202A,  // AF2
   UART3_TX_D8  = 0x2038,  // AF2
   UART4_TX_B0  = 0x2010,  // AF2
   UART4_TX_E0  = 0x2040,  // AF2
   UART4_TX_C10 = 0x102A,  // AF1
   UART5_TX_E8  = 0x2048,  // AF2
   UART5_TX_B4  = 0x2014,  // AF2
   UART5_TX_C12 = 0x102C,  // AF1
   UART6_TX_C0  = 0x1020,  // AF1
   UART6_TX_E10 = 0x204A,  // AF2
   UART6_TX_B8  = 0x2018,  // AF2
   UART7_TX_E12 = 0x20EC,  // AF2
   UART7_TX_A6  = 0x2006,  // AF2
   UART7_TX_C2  = 0x1022,  // AF1
   UART8_TX_E14 = 0x204E,  // AF2
   UART8_TX_A14 = 0x200E,  // AF2
   UART8_TX_C4  = 0x1024,  // AF1
}UART_TX_e;

typedef enum
{
   UART_1,
   UART_2,
   UART_3,
   UART_4,
   UART_5,
   UART_6,
   UART_7,
   UART_8,
}UARTn_e;

void Delay_Init(void);
void Delay_Us (uint32_t n);
void Delay_Ms (uint32_t n);
void USART_Printf_Init(uint32_t baudrate);

void nvic_init(IRQn_Type irqn,uint8_t pre_prior, uint8_t sub_prior,uint8_t status);
void UART_RX_IRQ_Config(USART_TypeDef* UARTx,u8 status);
void UART_TX_IRQ_Config(USART_TypeDef* UARTx,u8 status);
void UART_InitConfig(USART_TypeDef* UARTx,unsigned long baudrate,UART_TX_e tx_pin, UART_RX_e rx_pin);
void UART_PutStr(USART_TypeDef* UARTx,unsigned char *str);
void UART_PutChar(USART_TypeDef* UARTx,char ch);
void UART_PutBuff(USART_TypeDef* UARTx, u8 *buff, u16 len);
char UART_GetChar(USART_TypeDef* UARTx);
void DisableIRQ(IRQn_Type IRQn);
void EnableIRQ(IRQn_Type IRQn);
void LQ_V30xInit(void);

#ifdef __cplusplus
}
#endif

#endif 



