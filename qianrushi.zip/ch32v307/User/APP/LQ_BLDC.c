#include "include.h"

#define TRUE 1
#define FALSE 0

//#define Use_IR2304        //用2304无刷驱动板 请取消此注释  用2136无刷驱动板 需注释此代码
#define Use_IR2136        //用2136无刷驱动板 请取消此注释  用2304无刷驱动板 需注释此代码


#define BLDC_PWM_FREQUENCY    ATOM_PWM_MAX
BLDC_MANAGER g_sBLDCMag;    //无刷结构管理定义
int BLDCduty=800;         //无刷电机pwm
float y_vel_prev=0;         //低通滤波
float Speed_KP=0;
float Speed_KI=0;
uint16_t IA = 0,IB = 0,IC = 0;//三相电流定义
int Move_distance=20;//目标速度
/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void MotorInit(uint16 freq)
@功能说明：无刷电机引脚，pwm初始化
@参数说明：pwm 频率
@函数返回：无
@修改时间：2022/02/24
@调用方法：BLDC_MotorInit(1000-1);
@备    注：
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void BLDC_MotorInit(uint16 freq)
{
    //初始化四个PWM引脚
    PWM_InitConfig(PWM8_CH1_PC6, freq, 1000);
    PWM_InitConfig(PWM8_CH2_PC7, freq, 1000);
    PWM9_CH2PD11_CH3PD13_Init(freq, 1000);

    //初始化四个GPIO引脚
    PIN_InitConfig(PE3, GPO, 1, GPIO_Mode_Out_PP);
    PIN_InitConfig(PE4, GPO, 1, GPIO_Mode_Out_PP);
    PIN_InitConfig(PE5, GPO, 1, GPIO_Mode_Out_PP);
    PIN_InitConfig(PE6, GPO, 1, GPIO_Mode_Out_PP);

    g_sBLDCMag.Electricity_flag =TRUE;  //初始化电流判断条件，用于上电检测
}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void BLDC_HallInit(void);
@功能说明：初始化霍尔引脚及编码器接口
@参数说明：无
@函数返回：无
@修改时间：2022/02/24
@备    注：编码器接口同时为霍尔引脚状态读取接口
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void BLDC_HallInit(void)
{
    PIN_InitConfig(PD12, GPO, 1, GPIO_Mode_IN_FLOATING);    //浮空输入
    Encoder_Init(TIM1_ENCA_E9, TIM1_ENCB_E11);       //编码器1
}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：uint8_t Get_Hall_State(void);
@功能说明：读取霍尔状态
@参数说明：无
@函数返回：hall_state（霍尔状态）
@修改时间：2022/02/24
@备    注：
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
uint8_t Get_Hall_State(void)
{
  uint8_t hall_state = 0;

  if(PIN_Read(PD12))        //D12/* 读取霍尔传感器 U 的状态 */
  {
    hall_state |= 0x01U << 0;
  }
  if(PIN_Read(PE9))       //F12/* 读取霍尔传感器 V 的状态 */
  {
    hall_state |= 0x01U << 1;
  }
  if(PIN_Read(PE11))       //F13 /* 读取霍尔传感器 W 的状态 */
  {
    hall_state |= 0x01U << 2;
  }
  return hall_state;
}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void BLDC_Motor_Hall_Run(int16_t motor_duty);
@功能说明：无刷电机驱动函数，有霍尔
@参数说明：motor_duty（电机占空比）
@函数返回：无
@修改时间：2022/02/24
@备    注：
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void BLDC_Motor_Hall_Run(int16_t motor_duty)
{
  /* 获取霍尔传感器引脚状态,作为换相的依据 */
  g_sBLDCMag.step = Get_Hall_State();
  g_sBLDCMag.duty = motor_duty;
  if(g_sBLDCMag.Electricity_flag == TRUE)
  {
      if(motor_duty>=0)LQ_BLDCCorotation();//逆时针方向
      else if(motor_duty<0)LQ_BLDCReversal();
  }else{
      LQ_BLDCStop();
  }

}


#ifdef Use_IR2304
/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void LQ_BLDCCorotation(void);
@功能说明：控制无刷电机正转
@参数说明：无
@函数返回：无
@修改时间：2022/02/24
@备    注： 23.1->C7  21.2->D11 21.5->D13
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void LQ_BLDCCorotation(void)
{
    switch(g_sBLDCMag.step) //U+ U-  V+ V-  W+ W-
    {
    case 1:
        //A→B=0   B→C=-  C→A=+
        PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
        PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出0
        PWM_Set_Duty(PWM9_CH3_PD13, g_sBLDCMag.duty);   //PD13 输出PWM
      break;

    case 2:
        //A→B=-   B→C=+  C→A=0
        PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
        PWM_Set_Duty(PWM9_CH2_PD11, g_sBLDCMag.duty);   //PD11 输出PWM
        PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
      break;

    case 3:
        //A→B=-   B→C=+  C→A=0
        PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
        PWM_Set_Duty(PWM9_CH2_PD11, g_sBLDCMag.duty);   //PD11 输出PWM
        PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
      break;

    case 4:
        //A→B=+   B→C=0  C→A=-
        PWM_Set_Duty(PWM8_CH2_PC7, g_sBLDCMag.duty);    //PC7  输出PWM
        PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出0
        PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
      break;

    case 5:
        //A→B=0   B→C=-  C→A=+
        PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
        PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出0
        PWM_Set_Duty(PWM9_CH3_PD13, g_sBLDCMag.duty);   //PD13 输出PWM
      break;

    case 6:
        //A→B=+   B→C=0  C→A=-
        PWM_Set_Duty(PWM8_CH2_PC7, g_sBLDCMag.duty);    //PC7  输出PWM
        PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出0
        PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
      break;

    default:
      LQ_BLDCStop();
      break;
    }
}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void LQ_BLDCReversal(void);
@功能说明：控制无刷电机反转
@参数说明：无
@函数返回：无
@修改时间：2022/02/24
@备    注：23.1->C7  21.2->D11 21.5->D13
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void LQ_BLDCReversal(void)
{
    switch(g_sBLDCMag.step)
    {
      case 1:
          //A→B=+   B→C=0  C→A=-
          PWM_Set_Duty(PWM8_CH2_PC7, -g_sBLDCMag.duty);   //PC7  输出0
          PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出PWM
          PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
        break;

      case 2:
          //A→B=0  B→C=-  C→A=+
          PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
          PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出0
          PWM_Set_Duty(PWM9_CH3_PD13, -g_sBLDCMag.duty);  //PD13 输出PWM
        break;

      case 3:
          //A→B=+   B→C=0  C→A=-
          PWM_Set_Duty(PWM8_CH2_PC7, -g_sBLDCMag.duty);   //PC7  输出0
          PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出PWM
          PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
        break;

      case 4:
          //A→B=-   B→C=+  C→A=0
          PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
          PWM_Set_Duty(PWM9_CH2_PD11, -g_sBLDCMag.duty);  //PD11 输出PWM
          PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
        break;

      case 5:
          //A→B=-   B→C=+  C→A=0
          PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
          PWM_Set_Duty(PWM9_CH2_PD11, -g_sBLDCMag.duty);  //PD11 输出PWM
          PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
        break;

      case 6:
          //A→B=0   B→C=-  C→A=+
          PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
          PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出0
          PWM_Set_Duty(PWM9_CH3_PD13, -g_sBLDCMag.duty);  //PD13 输出PWM
        break;

      default:
        LQ_BLDCStop();
        break;
    }
}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void LQ_BLDCStop(void);
@功能说明：关闭无刷电机，停止运行
@参数说明：无
@函数返回：无
@修改时间：2022/02/24
@备    注：
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void LQ_BLDCStop(void)
{
    PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
    PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出0
    PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
    PIN_Write(PE4,0);   //关闭PE4
    PIN_Write(PE5,0);   //关闭PE5
    PIN_Write(PE6,0);   //关闭PE6
}
#else   //USE2136

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void LQ_BLDCCorotation(void);
@功能说明：控制无刷电机正转
@参数说明：无
@函数返回：无
@修改时间：2022/11/08
@备    注：23.1->C7  21.2->D11 21.5->D13
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void LQ_BLDCCorotation(void)
{
    switch(g_sBLDCMag.step)
    {
    case 1:
       //A→B=0   B→C=-  C→A=+
        PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX);                  //PC7  输出0
        PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX);                 //PD11 输出0
        PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX-g_sBLDCMag.duty);   //PD13 输出PWM
       break;

    case 2:
       //A→B=-   B→C=+  C→A=0
        PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX);                  //PC7  输出0
        PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX-g_sBLDCMag.duty);   //PD11 输出PWM
        PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX);                 //PD13 输出0
       break;

    case 3:
        //A→B=-   B→C=+  C→A=0
        PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX);                  //PC7  输出0
        PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX-g_sBLDCMag.duty);   //PD11 输出PWM
        PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX);                 //PD13 输出0
       break;

    case 4:
        //A→B=+   B→C=0  C→A=-
        PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX-g_sBLDCMag.duty);    //PC7  输出PWM
        PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX);                 //PD11 输出0
        PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX);                 //PD13 输出0
        break;

    case 5:
        //A→B=0   B→C=-  C→A=+
        PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX);                  //PC7  输出0
        PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX);                 //PD11 输出0
        PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX-g_sBLDCMag.duty);   //PD13 输出PWM
        break;

    case 6:
        //A→B=+   B→C=0  C→A=-
        PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX-g_sBLDCMag.duty);    //PC7  输出PWM
        PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX);                 //PD11 输出0
        PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX);                 //PD13 输出0
        break;
    default:
      LQ_BLDCStop();
      break;
    }
}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void LQ_BLDCReversal(void);
@功能说明：控制无刷电机反转
@参数说明：无
@函数返回：无
@修改时间：2022/02/24
@备    注：23.1->C7  21.2->D11 21.5->D13
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void LQ_BLDCReversal(void)
{
    switch(g_sBLDCMag.step)
    {
        case 1:
          //A→B=+   B→C=0  C→A=-
            PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX+g_sBLDCMag.duty);    //PC7  输出PWM
            PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX);                 //PD11 输出0
            PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX);                 //PD13 输出0
          break;

        case 2:
          //A→B=0  B→C=-  C→A=+
            PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX);                  //PC7  输出0
            PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX);                 //PD11 输出0
            PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX+g_sBLDCMag.duty);   //PD13 输出PWM
          break;

        case 3:
           //A→B=+   B→C=0  C→A=-
            PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX+g_sBLDCMag.duty);    //PC7  输出PWM
            PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX);                 //PD11 输出0
            PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX);                 //PD13 输出0
           break;

        case 4:
          //A→B=-   B→C=+  C→A=0
            PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX);                  //PC7  输出0
            PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX+g_sBLDCMag.duty);   //PD11 输出PWM
            PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX);                 //PD13 输出0
         break;

        case 5:
          //A→B=-   B→C=+  C→A=0
            PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX);                  //PC7  输出0
            PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX+g_sBLDCMag.duty);   //PD11 输出PWM
            PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX);                 //PD13 输出0
          break;

        case 6:
          //A→B=0   B→C=-  C→A=+
            PWM_Set_Duty(PWM8_CH2_PC7, PWM_DUTY_MAX);                  //PC7  输出0
            PWM_Set_Duty(PWM9_CH2_PD11, PWM_DUTY_MAX);                 //PD11 输出0
            PWM_Set_Duty(PWM9_CH3_PD13, PWM_DUTY_MAX+g_sBLDCMag.duty);   //PD13 输出PWM
         break;

        default:
          LQ_BLDCStop();
          break;
    }
}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void LQ_BLDCStop(void);
@功能说明：关闭无刷电机，停止运行
@参数说明：无
@函数返回：无
@修改时间：2022/02/24
@备    注：
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void LQ_BLDCStop(void)
{
    PWM_Set_Duty(PWM8_CH2_PC7, 0);                  //PC7  输出0
    PWM_Set_Duty(PWM9_CH2_PD11, 0);                 //PD11 输出0
    PWM_Set_Duty(PWM9_CH3_PD13, 0);                 //PD13 输出0
    PIN_Write(PE4,0);   //关闭PE4
    PIN_Write(PE5,0);   //关闭PE5
    PIN_Write(PE6,0);   //关闭PE6
}
#endif
/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：float LPF_velocity(float x);
@功能说明：一阶低通滤波器
@参数说明：传入需滤波的值
@函数返回：返回滤波后结果
@修改时间：2022/02/24
@备    注：
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
float LPF_velocity(float x)
{
  float y = 0.8*y_vel_prev + 0.2*x;
  y_vel_prev=y;
  return y;
}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：int LQ_BLDCCurrent_detection(void);
@功能说明：电流检测，保护电路
@参数说明：无
@函数返回：无
@修改时间：2022/02/24
@备    注：
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void LQ_BLDCCurrent_detection(void)
{
    g_sBLDCMag.counts ++;
    IA = (ADC1_Read_Average(ADC1ch9_B1,10)-2048)*3.3*100/4095/5/0.03;   //U    扩大100倍计算公式：(IA-2048)*3.3*100/4095/5/0.03≈IA/2    //2048是参考电压1.65
    IB = (ADC1_Read_Average(ADC1ch8_B0,10)-2048)*3.3*100/4095/5/0.03;  //V
    IC = (ADC1_Read_Average(ADC1ch1_A1,10)-2048)*3.3*100/4095/5/0.03;  //W    发现A相电流最大电阻特别容易烧，B相次之，C相最小，
    IA= LPF_velocity(IA);  //一阶低通滤波
    IB= LPF_velocity(IB);
    IC= LPF_velocity(IC);
    if((g_sBLDCMag.Electricity_flag ==TRUE)&&((IA/100>5.0)||(IB/100>5.0)||(IC/100>5.0)))
    {
        g_sBLDCMag.Electricity_flag =FALSE;
    }
    if((g_sBLDCMag.Electricity_flag ==FALSE)&&(IA/100<5.0)&&(IB/100<5.0)&&(IC/100<5.0) && (KEY_Read(KEY0) == 0))
    {
        g_sBLDCMag.Electricity_flag =TRUE;
        PIN_Write(PE4,1);   //打开PE4
        PIN_Write(PE5,1);   //打开PE5
        PIN_Write(PE6,1);   //打开PE6
    }
    if(g_sBLDCMag.counts > 1000)//超过2s，视为电机启动完毕不在检测启动电流
      g_sBLDCMag.counts=0,g_sBLDCMag.Electricity_flag =FALSE;
      while((IA/100>5)&&(IB/100>5)&&(IC/100>5)&&(ECPULSE1==0))
      {
          LQ_BLDCStop();//堵转后停止输出
          if(KEY_Read(KEY1)==0)break;
      }
}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void LQ_BLDCShow(void);
@功能说明：无刷电机相关数据展示
@参数说明：无
@函数返回：无
@修改时间：2022/02/24
@备    注：
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void LQ_BLDCShow(void)
{
    char txt[16];
#ifdef TFT18
    TFTSPI_P8X16Str(1, 2, "HALL Mode", u16WHITE, u16BLACK);
    if(g_sBLDCMag.Electricity_flag)
        TFTSPI_P8X16Str(1, 3, "TRUE ", u16RED, u16BLUE);
    else
        TFTSPI_P8X16Str(1, 3, "FALSE", u16RED, u16BLUE);
    sprintf(txt, "HALL:%02X", Get_Hall_State());
    TFTSPI_P8X16Str(1, 4, txt, u16WHITE, u16BLACK);

    sprintf(txt, "PWM:%05d", BLDCduty);
    TFTSPI_P8X16Str(1, 5, txt, u16WHITE, u16BLACK);       //字符串显示

    sprintf(txt, "I:%02d.%02d %02d.%02d %02d.%02d", IA/100,IA%100,IB/100,IB%100,IC/100,IC%100);
    TFTSPI_P8X16Str(1, 7, txt, u16WHITE, u16BLACK);

    sprintf(txt, "speed:%02d ",ECPULSE1);
    TFTSPI_P8X16Str(1, 1, txt, u16RED, u16BLUE);
#endif
#ifdef TFT20
    if(KEY_Read(DSW0)) TFT2SPI_P8X16Str(1, 2, "HALL Mode", u16WHITE, u16BLACK);
    else               TFT2SPI_P8X16Str(1, 2, "BEMF Mode", u16WHITE, u16BLACK);

    sprintf(txt, "HALL:%02X", Get_Hall_State());
    TFT2SPI_P8X16Str(1, 4, txt, u16WHITE, u16BLACK);

    sprintf(txt, "PWM:%05d", BLDCduty);
    TFT2SPI_P8X16Str(1, 5, txt, u16WHITE, u16BLACK);       //字符串显示

    sprintf(txt, "I:%02d.%02d %02d.%02d %02d.%02d", IA/100,IA%100,IB/100,IB%100,IC/100,IC%100);
    TFT2SPI_P8X16Str(1, 7, txt, u16WHITE, u16BLACK);

    sprintf(txt, "speed:%02d ",ECPULSE1);
    TFT2SPI_P8X16Str(1, 1, txt, u16RED, u16BLUE);

#endif


}

/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@函数名称：void TestMotorBLDC (void);
@功能说明：无刷电机测试函数
@参数说明：无
@函数返回：无
@修改时间：2022/11/8
@备    注： CH32V307的无刷例程
无刷驱动分为两种，两种都适用这个程序，接线方式一致，满PWM是5800，上面宏定义选择驱动驱动板型号
接线一定要对应！！！
接线一定要对应！！！
接线一定要对应！！！

三相电机线        A->黄色  B->黑色  C->红色
PWM信号接线：3V3-3.3V PWM1-C7 PWM2-E4 PWM3-D11 PWM4-E5 PWM5-D13 PWM6-E6 GND-GND
霍尔接线（直接接母版引脚）：红色->3.3  绿色->D12 棕色->E9 深黄色->E11 浅黄色->GND  （按顺序）
电流检测接线：GND-GND AO-B1 BO-B0 CO-A1

QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
void TestMotorBLDC (void)
{

#ifdef TFT18
    TFTSPI_Init(0);         //初始化屏幕0：横屏 1：竖屏
    TFTSPI_CLS(u16BLUE);    //清屏
    TFTSPI_P8X16Str(2, 0, "LQ BLDC Test", u16RED, u16BLUE);
#endif
#ifdef TFT20
    TFT2SPI_Init(1);        //初始化屏幕 0:竖屏 1横屏
    TFT2SPI_CLS(u16BLUE);   //清屏
    TFT2SPI_P8X16Str(1, 0, "LQ BLDC Test", u16RED, u16BLUE);
#endif
#ifdef OLED
    OLED_Init();            //OLED初始化
    OLED_CLS();             //LCD清屏
    sprintf((char*)txt,"ax:%06d",aacx);
    OLED_P6x8Str(2,0,"LQ BLDC Test");
#endif

    GPIO_LED_Init();            //LED初始化
    BLDC_HallInit();            //初始化霍尔引脚，读取霍尔值以及初略的编码值
    BLDC_MotorInit(12500);      //PWM GPIO初始化
    ADC1Init(ADC1ch9_B1);      //C3
    ADC1Init(ADC1ch8_B0);      //C4
    ADC1Init(ADC1ch1_A1);      //C5
    TIMER_InitConfig(TIMER_6, 1);  //TIM6定时器开启 100us一次
    while(1){
        LQ_BLDCCurrent_detection();     //电流检测，保护电路,可以修改电流上限（详见函数说明）
        LQ_BLDCShow();                  //显示相关数据，最好用TFT18

        if(KEY_Read(KEY0) == 0)         //按下KEY0键，占空比减小
        {
          if (BLDCduty > -4000)         //这里限制到了4000，满PWM是5800
            BLDCduty -= 100;
          while (KEY_Read(KEY0) == 0);  //防止连续检测
        }
        if(KEY_Read(KEY2) == 0)         //按下KEY2键，占空比加大
        {
          if (BLDCduty < 4000)          //这里限制到了4000，满PWM是5800
            BLDCduty += 100;
          while(KEY_Read(KEY2) == 0);   //防止连续检测
        }
        if(KEY_Read(KEY1) == 0)         //按下KEY1键，设置PWM为1500或-1500
        {
          if(BLDCduty>0)
              BLDCduty = -1500;
          else
              BLDCduty = 1500;
          while(KEY_Read(KEY1) == 0);
        }
        LED_Ctrl(LED1, RVS);            //电平翻转,LED1闪烁（B12）
        Delay_Ms(50);
    }
}









