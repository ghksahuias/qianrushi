//#ifndef USER_USART1_H_
//#define USER_USART1_H_
//#include "include.h"
//
//
//void USART1_Configuration(void);
//void USART_Send(USART_TypeDef *_UART,u8 *data, u8 len);
//void Send_data(u8 *s);
//
//#endif /* USER_USART1_H_ */
