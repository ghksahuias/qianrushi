#include "include.h"

int main(void) {
    LQ_V30xInit();
    GPIO_LED_Init();

	Test_LED();
	Test_KEY();
	Test_Beep();
	Test_EEPROM();
    TestMotor();
	TestEncoder();
	Test_LQDMP();
	Test_DVP();

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	Delay_Init();
    USART_Printf_Init(115200);
	printf("SystemClk:%d\r\n",SystemCoreClock);

	lcd_init();
	LCD_SetBrightness(40);
	lv_init();
	lv_port_disp_init();
	lv_example_arc_2();



    while(1)
    {
        lv_tick_inc(1);
        lv_task_handler();
        Delay_Ms(1);
        if(UART_GetChar(USART1)==01)
        {
         TestMotor();
        }
        else if(UART_GetChar(USART1)==02)
        {
         TestServo();
        }
    }
}
